import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Email setup
sender_email = "kousikkick123@gmail.com"
receiver_email = "capstone.kare@gmail.com"
password = "tkurqyqyrxnicceo"  # Use app-specific password for better security

# Create the email
message = MIMEMultipart()
message['From'] = sender_email
message['To'] = receiver_email
message['Subject'] = "Test Email"

# Email body
body = "This is a test email sent using Python!"
message.attach(MIMEText(body, 'plain'))

# Sending the email
try:
    # Connect to the server
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()  # Start TLS encryption
    
    # Login to the email account
    server.login(sender_email, password)
    
    # Send the email
    text = message.as_string()
    server.sendmail(sender_email, receiver_email, text)
    print("Email sent successfully!")
    
    # Quit the server
    server.quit()
    
except Exception as e:
    print(f"Failed to send email: {e}")
