from flask import Flask, render_template, request, redirect, url_for, flash
import os
from werkzeug.utils import secure_filename
from speech_to_text import transcribe_audio
from alert_system import send_alert

app = Flask(__name__)
app.secret_key = 'your_secret_key'
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'audiofile' not in request.files:
            flash('No file part')
            return redirect(request.url)
        
        file = request.files['audiofile']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)

        if file:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Step 1: Transcribe audio
            text = transcribe_audio(filepath)

            # Step 2: Check for distress and alert
            if "help" in text.lower() or "emergency" in text.lower():
                send_alert("User", "+911234567890", "Sample Location")

            flash(f"Transcribed text: {text}")
            return redirect(url_for('index'))
    return '''
    <!doctype html>
    <title>Upload Audio</title>
    <h1>Upload an Audio File for Distress Detection</h1>
    <form method=post enctype=multipart/form-data>
      <input type=file name=audiofile>
      <input type=submit value=Upload>
    </form>
    '''

if __name__ == '__main__':
    app.run(debug=True)
