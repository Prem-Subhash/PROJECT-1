from flask import Flask, render_template, request
import os
import uuid
import assemblyai as aai
from fuzzywuzzy import fuzz
import subprocess

# === CONFIGURATION ===
UPLOAD_FOLDER = r"C:\Users\saida\Downloads\updated_codee\codee\codee\uploads"
FFMPEG_PATH = r"C:\ffmpeg\bin\ffmpeg.exe"  # adjust if different

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['ALLOWED_EXTENSIONS'] = {'mp3', 'wav', 'm4a', 'webm', 'mp4'}

# Create upload directory if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# AssemblyAI API key
aai.settings.api_key = "d61be246db6c4f08847ee3a4a015aad9"

# Keywords for distress detection
distress_keywords = [
    "help", "emergency", "urgent", "injury", "bleeding", "accident", "pain", "danger",
    "fire", "unconscious", "choking", "send help", "immediate assistance", "please help",
    "heart attack", "stroke"
]

# === UTILITY FUNCTIONS ===

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def detect_distress(text):
    for keyword in distress_keywords:
        if fuzz.partial_ratio(keyword.lower(), text.lower()) > 80:
            return True
    return False

def convert_video_to_audio(video_path):
    audio_path = os.path.splitext(video_path)[0] + ".wav"
    command = [
        FFMPEG_PATH,
        "-i", video_path,
        "-vn",  # no video
        "-acodec", "pcm_s16le",
        "-ar", "16000",
        "-ac", "1",
        audio_path
    ]
    try:
        subprocess.run(command, check=True)
        return audio_path
    except subprocess.CalledProcessError as e:
        print("FFmpeg failed:", e)
        return None

def process_audio(file_path):
    try:
        upload_url = aai.upload(file_path)
    except Exception as e:
        return None, f"Upload to AssemblyAI failed: {e}"

    transcriber = aai.Transcriber()
    try:
        transcript = transcriber.transcribe(upload_url)
    except Exception as e:
        return None, f"Transcription error: {e}"

    if transcript.status == aai.TranscriptStatus.error:
        return None, transcript.error

    text = transcript.text
    is_distress = detect_distress(text)
    return text, is_distress

# === ROUTES ===

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload2', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files.get('file')
        if file and allowed_file(file.filename):
            filename = f"{uuid.uuid4().hex}_{file.filename}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            ext = filename.rsplit('.', 1)[1].lower()
            if ext in ['webm', 'mp4']:
                audio_path = convert_video_to_audio(filepath)
                if not audio_path:
                    return render_template('upload.html', error="Audio extraction failed.")
            else:
                audio_path = filepath

            transcript_text, is_distress = process_audio(audio_path)
            if transcript_text:
                return render_template('results2.html', transcript=transcript_text, is_distress=is_distress)
            else:
                return render_template('upload.html', error="Transcription failed.")
        else:
            return render_template('upload.html', error="Invalid file type.")
    return render_template('upload.html')

if __name__ == '__main__':
    app.run(debug=True)
