def transcribe_audio(audio_path):
    # Dummy transcription logic
    print(f"Processing {audio_path}")
    return "This is a simulated transcription with help keyword"
