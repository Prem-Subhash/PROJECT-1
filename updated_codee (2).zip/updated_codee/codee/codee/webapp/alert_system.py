def send_alert(username, contact_number, location):
    print(f"Sending alert for {username} to {contact_number} at {location}")
    # Integrate Twilio here if needed
